# Filesystem Enforcement Demo

Network was the first half of Pillar 1. Filesystem is the other half — and arguably the more visceral one for security teams. *"The agent can't steal SSH keys"* lands harder than *"the agent can't reach paste.ee."*

Same model as Section 03: define rules in the Admin Console, watch them flow to your machine, prove enforcement inside a sandbox.

**Time:** ~10 minutes
**Prerequisites:** You completed Section 03 (so policies, governance, and sandbox flow are familiar).

## What you'll prove

- Deny rules block specific paths even when the sandbox has visibility into them
- Allow rules permit access to scoped directories
- The default-deny posture catches anything outside your allowlist
- Read/Write actions can be scoped independently — an agent can read code but not modify it

## Step 1 — Open the Admin Console

Open **[app.docker.com/admin/orgs/$$org$$](https://app.docker.com/admin/orgs/$$org$$)** and navigate to **AI governance** → **Filesystem access**.

The page works the same way as Network access, but rules are scoped to paths (with glob support) and actions (Read / Write).

## Step 2 — Add the allow rules

You'll define what the agent *can* touch.

**Rule 1: allow code directory**

- Action: **Allow**
- Filesystem path:
  ```
  ~/work/**
  ~/code/**
  ~/Documents/projects/**
  ```
  *(Use whatever directory you actually keep code in. The `**` matches recursively across subdirectories.)*
- Action scope: **Read, Write**
- Name: `allow code directories`

**Rule 2: allow scratch (read-only)**

- Action: **Allow**
- Filesystem path: `~/scratch/**`
- Action scope: **Read** only (no Write)
- Name: `allow scratch read-only`

Read-only scratch demonstrates that Read and Write can be scoped independently — important for security teams who want agents to *review* code without modifying it.

## Step 3 — Add the deny rules

These are the rules that earn their keep.

**Rule: deny credentials**

- Action: **Deny**
- Filesystem path:
  ```
  ~/.ssh/**
  ~/.aws/**
  ~/.config/gcloud/**
  ~/.kube/config
  ~/.docker/config.json
  ```
- Action scope: **Read, Write** (both)
- Name: `deny credentials`

That covers SSH keys, AWS creds, GCloud creds, K8s config, and Docker registry auth — the five places agents most commonly leak secrets from.

## Step 4 — Remove any catch-all

Same trap as Network access. If a rule exists with path `~/**` or `/**` and action Allow, **delete it**. A catch-all allow defeats every deny rule.

After this, the filesystem rule list should have exactly **3 rules**:

- allow code directories (Allow Read+Write)
- allow scratch read-only (Allow Read)
- deny credentials (Deny Read+Write)

## Step 5 — Verify policies reached your machine

On your terminal:

```bash terminal-id=main
sbx policy reset
```

Choose **Balanced** when prompted.

Then look specifically at filesystem rules:

```bash terminal-id=main
sbx policy ls
```

You should see your three filesystem rules with `ORIGIN: remote`, and any local filesystem defaults marked `inactive — corporate policy takes precedence`.

## Step 6 — Spin up a sandbox with the home mount

For this demo we deliberately give the sandbox visibility into your home directory — exactly the over-permissive setup you want governance to defend against:

```bash terminal-id=main
mkdir -p ~/scratch && cd ~/scratch
sbx run shell . ~:ro
```

The `~:ro` mounts your home directory as read-only into the sandbox. **A naïve developer might mount their home like this so an agent can "see everything."** With filesystem governance, specific paths inside that mount are still locked down.

You'll land at the sandbox shell prompt.

## Step 7 — Run the filesystem tests

Inside the sandbox, run all four:

```bash terminal-id=main
ls ~/.ssh/ 2>&1 | head -3
cat ~/.aws/credentials 2>&1 | head -3
ls ~/work/ 2>&1 | head -3
ls ~/Downloads/ 2>&1 | head -3
```

## Step 8 — Read the results

Expected behavior:

| Command | Expected | What it means |
| --- | --- | --- |
| `ls ~/.ssh/` | Permission denied / no such file | `deny credentials` rule blocked the read |
| `cat ~/.aws/credentials` | Permission denied / no such file | `deny credentials` rule blocked the read |
| `ls ~/work/` | Lists your code files | `allow code directories` rule permitted the read |
| `ls ~/Downloads/` | Permission denied / no such file | Default-deny — no allow rule covers `~/Downloads/` |

The same three-decision pattern as the network demo: explicit allow, explicit deny, and default-deny.

## Step 9 — Exit the sandbox

```bash terminal-id=main
exit
```

## What you just demonstrated

You proved that **even when a developer over-permissively mounts their home directory**, the org's filesystem policies still defend the credentials. The CISO does not have to trust every developer's mount discipline — governance enforces the boundary.

Combined with Section 03, you've now proven Pillar 1 end-to-end across both surfaces it controls:

- **Network egress** — agent can't reach unapproved destinations
- **Filesystem access** — agent can't read unapproved files

That's the complete sandbox policies story.

## Validation note before you ship this lab

The exact enforcement boundary for filesystem rules may vary by `sbx` version. Two possible implementations:

1. **Mount-time enforcement** — `sbx run` rejects mounting paths that violate deny rules. In this model, attempting `sbx run shell . ~:ro` with a deny rule for `~/.ssh/**` might fail at sandbox creation rather than at file-access time inside.
2. **Runtime enforcement** — the mount succeeds, but file reads inside the sandbox are intercepted at the FUSE/syscall layer.

**Run Step 7 yourself once before using this lab with an audience.** If the results look different from the table above, update the table to match what your version does. Either implementation tells the same defensive story — just adjust the narrative to fit.

## Common questions

**"What if the developer doesn't mount home at all?"**
Then there's nothing to filter — the agent only sees the explicit workspace. Filesystem rules only matter when something *is* mounted. They're defense-in-depth for the over-permissive case.

**"Can the developer use `--no-policy` or similar to bypass this?"**
No. Local sbx flags can adjust what gets mounted, but org policies always evaluate. The developer can choose to mount less, but cannot expose more than the policy permits.

**"What about files written *during* the sandbox session?"**
Writes are scoped to the explicit workspace (`.` in our `sbx run` command) and any paths covered by an Allow Write rule. Without an explicit Write allow for a path, writes fail — even to paths that Read allows.

**"How does this interact with the Network rules from Section 03?"**
Both run through the same policy engine, evaluated in parallel. A request to read a file goes through the filesystem check; a request to make a network call goes through the network check. Both share the audit trail covered in Section 05.

Move on to Section 05 for a preview of audit trails and MCP governance.
